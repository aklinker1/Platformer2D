java -Djava.library.path=./bin -XstartOnFirstThread -jar Platformer2D.jar

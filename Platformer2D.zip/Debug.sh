java -Djava.library.path=./natives -jar Platformer2D.jar
PAUSE
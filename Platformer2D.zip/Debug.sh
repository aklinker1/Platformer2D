java -jar Platformer2D.jar
PAUSE
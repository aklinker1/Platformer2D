java -Djava.library.path=./bin -jar Platformer2D.jar
PAUSE
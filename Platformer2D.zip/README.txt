To run the program, double click the jar.
To show the debugger, run the script 'Debug.sh'.